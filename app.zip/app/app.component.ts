import { Component } from '@angular/core';
import {HttpClientModule} from '@angular/common/http';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  get1;
  get2;
  enableEdit = false;
  enableEditIndex = null;
  editField;
  myvar;

  constructor(private http: HttpClient){
  
  }

  save(data){
    if(data.id="")
    {
    this.http.post<any>('http://192.168.0.155:70/PMS_Design/test.php',{ 
      "firstname":data.firstName, 
      "lastname": data.lastName,
  }).subscribe(
      response1=>{this.get1 =  response1;}
    );
    this.nn();
  }
  else{

    

    console.log(data);
  }

  }

  ngOnInit(){
 this.nn();
  
  }
  nn(){
    this.http.get("http://192.168.0.155:70/PMS_Design/test2.php").subscribe(
      response2=>{this.get2 = response2;}
    )



  }

 

  update(data){
 console.log (data);
  this.myvar=data;

  }
  
  delete(data){

    this.http.post<any>('http://192.168.0.155:70/PMS_Design/test4.php',{ 
      "firstname":data.firstName, 
      "lastname": data.lastName,
      "id": data.id,
  }).subscribe(
      response1=>{this.get1 =  response1;}
    );

 this.nn();

  }
  

  
}
  